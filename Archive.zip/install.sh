#!/usr/bin/env bash

python3.6 -m pip install --system --target . python-astar